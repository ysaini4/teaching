<html lang="en">

<head>
<script type="text/javascript" src="js/jquery-1.2.6.pack.js"></script>
<link rel="stylesheet" type="text/css" href="css/stylesheet.css"/>
</head>
<body>
<a href="#" class="showpopup">Link</a>


</body>

<script type="text/javascript">
				
</script>
</html>
