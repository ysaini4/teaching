<?php

echo "This  view is called with month Argument = ".$month;

?>
ertyui