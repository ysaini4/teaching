  <!-- Footer -->
  <footer class="page-footer teal">
    <div class="container ">
      <div class="row">
        <div class="col l4 s12">
          <h5 class="white-text">Get IITians</h5>
          <a class="grey-text text-lighten-3" href="#"><i class="mdi-communication-email"></i> Info@getIITians.com</a>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      &copy; Copyright 2015 getIITians
      <a class="grey-text text-lighten-4 right" href="#!">www.getIITians.com</a>
      </div>
    </div>
  </footer>

 