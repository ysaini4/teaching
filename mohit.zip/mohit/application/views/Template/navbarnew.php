  <!-- Account Dropdown -->
  <body>
  
  <!-- NavBar -->
  <div class="navbar-fixed">
    <nav class="teal" role="navigation">
      <div class="nav-wrapper container">
        <a href="<?php echo HOST ;?>" class="brand-logo">getIITians</a>
        <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="mdi-navigation-menu"></i></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
         
          <li><a href="<?php echo BASE."aboutus" ;?>">About us</a></li>
          <li><a href="<?php echo BASE."contactus" ;?>">Contact us</a></li>
          <li><a href="<?php echo BASE."joinus" ;?>"><i class="mdi-action-account-circle left"></i>Join Us</a></li>

          
        </ul>
      </div>
    </nav>
  </div>
  <!-- SideNav -->
  <ul class="side-nav" id="mobile-demo">
    <li><a href="<?php echo BASE."aboutus" ;?>">About</a></li>
    <li><a href="<?php echo BASE."contactus" ;?>">Contact</a></li>
    <li><a href="<?php echo BASE."joinus" ;?>"><i class="mdi-action-account-circle left"></i>Join Us</a></li>
    
    <li>
      <form>
        
      </form>
    </li>
  </ul>
