<!doctype html>
<html>
<head>

  <?php
  opent("base",array("href"=>HOST));
  ocloset("title",$title);
  addall_css($css);
  addmycss();
  ?>
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
   <script type="text/javascript">
   	var HOST="<?php echo HOST; ?>";
   </script>
</head>
