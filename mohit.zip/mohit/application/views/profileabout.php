<?php
?>
   <main>
    <div class="container_profile">
    <div class="section">
        <br>
    <div class="row">
    <div class="col s12  l12">
        <div class="card-panel_profile" style=" margin-bottom: 0px;">
             <h4 ><i class="small mdi-action-account-circle"></i>ABOUT</h4>
        <div class="row">
          <div class="col s5">
            <div class="row">
              <label class="label1">First Name:</label>
              Mariah
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1">Last Name:</label>
              Caraiban
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >User Name:</label>
                Mariah
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Email:</label>
               someone@e.com 
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >City:</label>
              Los Angeles 
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Country:</label>
               jkbkj
              <!-- col-sm-10 --> 
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Birthday:</label>
                22, 1984
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Gender</label>
              Male
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Resume</label>
              <a href"#">resume</a>
                 
            </div>
          </div>
          <div class="col s5">
            <div class="row">
              <label class="label1" >Phone:</label>
              9999999999
            </div>
          </div>
        </div>
        </div>
        <div class="card-panel_profile" style=" margin-bottom: 0px;">
            <h4 ><i class="small mdi-social-group"></i>Teaching Details</h4>
        <div class="row">
            <div class="col s5">
                 <div class="row">
            <div class="col s6">
                 <div class="row">
                     <label class="label1" >Subjects</label>
                     <ul class="scroll_list"><li>mathematics</li>
                         <li>german</li>
                          <li>science</li>
                          <li>chemistry</li>
                          <li>physics</li>
                          <li>english</li>
                     </ul>

                 </div>
            </div>
        
            <div class="col s4">
            <div class="row ">
             <label class="label1" >Grade</label>
                     <ul class="scroll_list"> <li>1</li>
                          <li>2</li>
                          <li>3</li>
                          <li>4</li>
                          <li>5</li>
                          <li>6</li>
                          <li>7</li>
                          <li>8</li>
                     </ul>
            </div>
          </div>
                </div>
            </div>
            <div class="col s5">
            <div class="row ">
             <label class="label1" >Languages</label>
                     <ul class="scroll_list">
                         <li>English</li>
                          <li>hindi</li>
                          <li>sanskrit</li>
                          
                     </ul>
            </div>
          </div>
            </div>
            <div class="row">
            <div class="col s5">
            <div class="row ">
              <label class="label1" >Fees</label>
              1300
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Experience</label>
              4 Yrs.
            </div>
          </div>
        </div>
            
        </div>
         <div class="card-panel_profile" style=" margin-bottom: 6px; padding-bottom: 8px;">
             <h4><i class="small mdi-social-school"></i>Educational Details</h4>
        <div class="row">
          <div class="col s5">
            <div class="row">
              <label class="label1" >College</label>
              IIT
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1">College ID</label>
              80055
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Degree</label>
                B.tech
            </div>
          </div>
          <div class="col s5">
            <div class="row ">
              <label class="label1" >Branch</label>
                        Cse
              </div>
          </div>
        </div>
        </div>
        <br>
        </div> 
       </div>
       </div>
       </div>
</main>
