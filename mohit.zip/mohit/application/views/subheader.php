<?php
load_view("Template/top.php");
?>
<?php
load_view("Template/bottom.php");
?>