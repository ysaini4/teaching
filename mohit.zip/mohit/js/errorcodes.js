
var ecn={
		"-1":"Session expired",
		"-2":"You are not right person to perform this action.",
		"-3":"Incorrect formate of input",
		"-4":"Password incorrect",
		"-5":"Username doesn't exist",
		"-6":"No Such email id registered",
		"-7":"Action handler not defined",
		"-8":"Session expired or You are not right person to perform this action.",
		"-9":"Not sufficient arguments.",
		"-10":"No resume selected.",
		"-11":"Sorry,you cannot perform this Action\nYour session expired or .",
		"-12":"Not Valid application position.",


		"-13":"Don't try to be smart.",
		

		"-14":"Already Added.",
		"-15":"Cannot fill it.time passed.",

		"-16":"This email id used Already",
		"-17":"OTP is incorrect",
		"-18":"Some unknown error while creating account.",

		"-19":"You cannot choose slot of past.",

		"-20":"You Cannot generate link",

		
		"1":"Positive"
		
	};
