<?php
class Cal{
	public $wdays;
	public $months;
	function __construct(){
		$this->wdays=array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");
		$this->$months=array("Jan"."Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec");
	}
	function 




}
?>
