<?php
class User extends Sql{
	public static function way2sms($phone,$msg){

	}
	public static function sms($phone,$msg){
		
	}
}
?>
