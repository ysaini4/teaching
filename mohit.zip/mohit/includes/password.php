<?php
$sec=array();
$sec['encode1']='Bkvas1';
$passkey=array();
$passkey["key1"]="MSV";
?>