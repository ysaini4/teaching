


<div style='height:500px;' >
</div>

<?php
popupalert(null);
popupconfirm(null);
?>
<script src="<?php echo HOST; ?>bootstrap-3.1.1-dist/js/jquery1.js" ></script>
<script src="<?php echo HOST; ?>bootstrap-3.1.1-dist/js/bootstrap.js" ></script>
<script src="<?php echo HOST; ?>bootstrap-3.1.1-dist/js/lib.js" ></script>
<script src="<?php echo HOST; ?>bootstrap-3.1.1-dist/js/mohit.js" ></script>
<script src="<?php echo HOST; ?>js/errorcodes.js" ></script>
<script src="<?php echo HOST; ?>js/mohitlib.js" ></script>
<script src="<?php echo HOST; ?>js/main.js" ></script>
</body>
</html>

